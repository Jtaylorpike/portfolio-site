﻿# Taylor Pike Portfolio Chat Upload Manifest

Created: 2026-05-11 11:56:55
Project root: C:\Users\jtayl\portfolio-site
Package root: C:\Users\jtayl\portfolio-site\_chat-uploads\TaylorPikePortfolio-ChatUpload-20260511-115654

## Included source files
- index.html
- package.json
- package-lock.json
- vite.config.ts
- tsconfig.json
- README.md
- .gitignore

## Included source directories
- src
- scripts
- local-editor

## Missing expected files or folders
- None

## Runtime image package
- Included optimized/card/gallery/logo/imported runtime images available in the project.

## Original/full image package
- Not included. Use -IncludeOriginalImages only when full/original image processing matters.

## Excluded by design
- node_modules/ because dependencies can be recreated with npm install.
- dist/ because it is generated build output.
- .drive-browser-profile/ because it is local browser cache/profile data.
- .git/ because repository internals are unnecessary for ChatGPT review.
- _chat-uploads/ because upload packages should not recursively include older upload packages.
- old generated replacement packs and zip packs because they can be stale.
- local-editor/backups/ by default because backup history is noisy unless specifically needed.
- *.bak, *.backup-*, *.pyc, __pycache__/, *.tmp, and logs because they are local artifacts.

## Upload instruction for the next chat
Upload this zip after the latest transfer kit or handoff summary. Treat current source files as source of truth. Treat summaries as memory backups only. Do not treat generated build output, old replacement packs, browser cache, or backup files as active source.
